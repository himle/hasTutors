import System.Console.CmdArgs
import System.Directory (doesDirectoryExist)
import System.FilePath (takeFileName)

import Development.Shake
import Development.Shake.FilePath
